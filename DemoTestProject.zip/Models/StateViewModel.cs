﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DemoTestProject.Models
{
    public class StateViewModel
    {
        public int Id { get; set; }
        public string state { get; set; }
        
        public string Country { get; set; }
    }
}