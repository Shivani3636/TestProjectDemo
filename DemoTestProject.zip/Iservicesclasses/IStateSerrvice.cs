﻿using DemoTestProject.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoTestProject.Iservicesclasses
{
    public interface IStateSerrvice
    {
        bool CreateState(TableState state);
        bool DeleteState(int stateId);
        TableState GetStateById(int stateId);
        List<TableState> GetAllState();
    }
}
