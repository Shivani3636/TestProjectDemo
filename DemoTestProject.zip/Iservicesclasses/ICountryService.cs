﻿using DemoTestProject.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoTestProject.Iservicesclasses
{
    public interface ICountryService
    {
        bool AddEditCountry(TableCountry table);
        bool DeleteCountry(int countryId);
        List<TableCountry> GetAllCountry();

    }
}
