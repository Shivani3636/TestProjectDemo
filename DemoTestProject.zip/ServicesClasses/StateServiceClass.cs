﻿using DemoTestProject.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Migrations;
using System.Linq;
using System.Web;

namespace DemoTestProject.ServicesClasses
{
    public class StateServiceClass
    {
        Database1Entities _context;
        public StateServiceClass()
        {
            _context = new Database1Entities();
        }
        public bool CreateState(TableState state)
        {

            _context.TableStates.AddOrUpdate(state);
            int result = _context.SaveChanges();
            if (result > 0)
            {
                return true;

            }
            else
            {
                return false;
            }
        }
        public bool DeleteState(int stateId)
        {
            var state = _context.TableStates.FirstOrDefault(x => x.Id.Equals(stateId));
            _context.TableStates.Remove(state);
            int result = _context.SaveChanges();
            if (result > 0)
            {
                return true;

            }
            else
            {
                return false;
            }

        }
        public TableState GetStateById(int stateId)
        {
            return _context.TableStates.FirstOrDefault(x=>x.Id.Equals(stateId));
        }
        public List<StateViewModel> GetAllState()
        {
            var records =   _context.TableStates.Include(x=>x.TableCountry).ToList();
            List<StateViewModel> list = new List<StateViewModel>();
            foreach (var item in records)
            {
                list.Add(
                        new StateViewModel()
                        {
                            Id= item.Id,
                            state=item.state,
                            Country = item.TableCountry.Country
                        }
                    );
            }
            return list;
        }

    }
}