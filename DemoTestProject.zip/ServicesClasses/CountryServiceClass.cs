﻿using DemoTestProject.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity.Migrations;
using System.Linq;
using System.Web;

namespace DemoTestProject.ServicesClasses
{
    public class CountryServiceClass
    {
        Database1Entities _database;
        public CountryServiceClass() 
        { 
            _database = new Database1Entities();
        }
        public bool AddEditCountry(TableCountry table)
        {

            _database.TableCountries.AddOrUpdate(table);
            int result=_database.SaveChanges();
            if(result > 0)
            {
                return true;

            }
            else
            {
                return false;
            }
        }
        public bool DeleteCountry(int countryId)
        {
            var country = _database.TableCountries.FirstOrDefault(x=>x.Id.Equals(countryId));
            _database.TableCountries.Remove(country);
            int result = _database.SaveChanges();
            if (result > 0)
            {
                return true;

            }
            else
            {
                return false;
            }
        }
        public List<TableCountry> GetAllCountry()
        {
            return _database.TableCountries.ToList();
        }
    }
}