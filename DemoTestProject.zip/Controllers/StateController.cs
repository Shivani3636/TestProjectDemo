﻿using DemoTestProject.Iservicesclasses;
using DemoTestProject.Models;
using DemoTestProject.ServicesClasses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DemoTestProject.Controllers
{
    public class StateController : Controller
    {
        // GET: State
        public StateServiceClass _state;
        public CountryServiceClass _country;
        public StateController() 
        { 
            _state = new StateServiceClass();
            _country= new CountryServiceClass();
        }
        public ActionResult Index()
        {
            return RedirectToAction("GetAllState");
        }

        [HttpGet]
        public ActionResult CreateState()
        {
            ViewBag.Countries = _country.GetAllCountry();
            return View();
        }
        [HttpPost]
        public ActionResult CreateState(TableState table)
        {
            if (_state.CreateState(table))
            {
                return RedirectToAction("GetAllState");
            }
            return View(table);
        }
        public ActionResult DeleteState(int stateId)
        {
            if (_state.DeleteState(stateId))
            {
                return RedirectToAction("GetAllState");
            }
            return View();
        }

        [HttpGet]
        public ActionResult Edit(int stateId)
        {

            ViewBag.Countries = _country.GetAllCountry();
            var record = _state.GetStateById(stateId);
            return View(record);
        }

        [HttpPost]  
        public ActionResult Edit(TableState table)
        {
            if (_state.CreateState(table))
            {
                return RedirectToAction("GetAllState");
            }
            return View(table);
        }
        public ActionResult  GetAllState()
        {
            var states = _state.GetAllState();
            return View(states);
        }
    }
}