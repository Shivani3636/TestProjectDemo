﻿using DemoTestProject.Iservicesclasses;
using DemoTestProject.Models;
using DemoTestProject.ServicesClasses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DemoTestProject.Controllers
{
    public class CountryController : Controller
    {
        // GET: Country
        public CountryServiceClass _country;
        public CountryController() 
        { 
            _country = new CountryServiceClass();
        }

        [HttpGet]
        public ActionResult AddEditCountry()
        {
            return View();
        }
        [HttpPost]
        public ActionResult AddEditCountry(TableCountry table)
        {
            if (_country.AddEditCountry(table))
            {
                return RedirectToAction("GetAllCountry");
            }
            return View(table);
        }

        [HttpGet]
        public ActionResult Edit(int id)
        {
            var record = _country.GetAllCountry().FirstOrDefault(x=>x.Id==id);
            return View(record);
        }
        [HttpPost]
        public ActionResult Edit(TableCountry table)
        {
            if (_country.AddEditCountry(table))
            {
                return RedirectToAction("GetAllCountry");
            }
            return View(table);
        }
        public ActionResult DeleteCountry(int countryId)
        {
            if (_country.DeleteCountry(countryId))
            {
                return RedirectToAction("GetAllCountry");
            }
            return View();
        }
        public ActionResult GetAllCountry()
        {
            var countries = _country.GetAllCountry();
            return View(countries);
        }
        public ActionResult Index()
        {
            return RedirectToAction("GetAllCountry");
        }
    }
}